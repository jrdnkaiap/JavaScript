var hellogame = function() {
   var name = window.prompt("Type your name");
   document.write("Hello ", name)
};
