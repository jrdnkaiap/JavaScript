//************************************************************
var trianglearea = function() {
  var base = parseFloat(document.getElementById('Base').value);
  var height = parseFloat(document.getElementById('Height').value);

  var output = document.getElementById('output');

  if (isNaN(base) || isNaN(height)) {
    output.textContent = "You did not enter two numbers.";
  } else {
    var area = 0.5 * base * height;
    output.textContent = "Area = " + area;
 }
}
//var DrawTriangle function(base, height) {
   //var canvasElement = document.getElementById('myCanvas');
   //var context = canvasElement.getContext("2d");


//}
