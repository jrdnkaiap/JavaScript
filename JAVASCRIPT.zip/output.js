console.log(1+1+1+1+1+1+1);
