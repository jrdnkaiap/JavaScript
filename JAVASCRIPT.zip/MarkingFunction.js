var input = Window.prompt("Enter Mark!")



function mark(grade){
  parseInt(grade)
  let tempgrade = Math.trunc(grade/10);
  switch (tempgrade) {
    case 10:
    case 9:
      console.log('A');
      break;
    case 8:
      console.log('B');
      break;
    case 7:
      console.log('A');
      break;
    case 6:
      console.log('B');
      break;
    default:
      console.log('F');

  }
}
