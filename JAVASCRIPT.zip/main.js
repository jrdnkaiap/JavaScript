<button onclick="myFunction()">Click Me!</button>

<script>
   function myFunction() {
      alert("Go Away")
   }
</script>
